from muxlink.muxlink import MuxLink

# this function is used to get the key acc/precision/kpa from the key string
def get_key_result(key_string_ori, key_string_extracted):
    key_ori_list = list(key_string_ori)
    key_extracted_list = list(key_string_extracted)
    # print(key_ori_list)
    # print(key_extracted_list)
    key_acc = 0
    for i in range(len(key_ori_list)):
        if key_ori_list[i] == key_extracted_list[i]:
            key_acc += 1
    key_acc = key_acc / len(key_ori_list)
    return key_acc

def netlist_encode(netlist_str, circuit_name):
    muxlink = MuxLink(circuit_name)
    kgss = muxlink.encode(netlist_str)
    # print(dict(kgss.graph.nodes()))
    return kgss

# this function is used to attack the circuit using SAAM algorithm
def saam_attack(netlist_str, circuit_name, kgss):
    # encode the netlist and get the
    kgss_ori = netlist_encode(netlist_str, circuit_name)
    # get the solution data
    kgss_data = kgss.data
    # print("kgss_data", kgss_data)
    kgss_graph = kgss_ori.graph
    original_key = kgss.get_key_value()
    G_info = dict(list(kgss_graph.nodes(data="count")))
    G_info_updated = {y: x for x, y in G_info.items()}
    for item in kgss_data:
        [_, f2_temp, g1_temp] = [int(i) for i in item[0:3]]
        # f1_temp = G_info_updated[f1_temp]
        f2_temp = G_info_updated[f2_temp]
        g1_temp = G_info_updated[g1_temp]
        # add the edge 
        kgss_graph.add_edge(f2_temp, g1_temp)
    # attack_f1f2= []
    # attack_f1f2name = []
    key_string = ''
    for item in kgss_data:
        [f1, f2] = [int(i) for i in item[0:2]]
        key_temp = int(item[4])
        # based on the count number, find the node name
        f1 = G_info_updated[f1]
        f2 = G_info_updated[f2]
        # g1 = G_info_updated[g1]
        # g2 = G_info_updated[g2]
        # find the fanout size of f1 and f2
        f1_fanout = len(list(kgss_graph.successors(f1)))
        f2_fanout = len(list(kgss_graph.successors(f2)))
        if f1_fanout >1 and f2_fanout > 1:
                key_string += 'X'
        if key_temp == 0:
            if f1_fanout == 1:
                key_string += '0'
            elif f2_fanout == 1:
                key_string += '1'
        elif key_temp == 1:
            if f1_fanout == 1:
                key_string += '1'
            elif f2_fanout == 1:
                key_string += '0'
        # else:
        #     key_string += 'X'
        #     attack_f1f2name.append([f1, f2])
        #     attack_f1f2.append([f1_fanout, f2_fanout])
    # print("attack_f1f2", attack_f1f2)
    # print("attack_f1f2name", attack_f1f2name)
    # print(len(kgss_data))
    # print("original_key", original_key)
    print("key_string", len(key_string))
    key_X_count = key_string.count('X')
    print("key_X_count", key_X_count)
    # key_acc = (len(original_key)-key_X_count)/len(original_key)
    key_acc = get_key_result(original_key, key_string)    
    return key_acc

def saam_attack_check(netlist_str, circuit_name, kgss):
    # encode the netlist and get the
    kgss_ori = netlist_encode(netlist_str, circuit_name)
    # get the solution data
    kgss_data = kgss.data
    # print("kgss_data", kgss_data)
    kgss_graph = kgss_ori.graph
    original_key = kgss.get_key_value()
    G_info = dict(list(kgss_graph.nodes(data="count")))
    G_info_updated = {y: x for x, y in G_info.items()}
    for item in kgss_data:
        [f1_temp, f2_temp, g1_temp, g2_temp] = [int(i) for i in item[0:4]]
        f1_temp = G_info_updated[f1_temp]
        f2_temp = G_info_updated[f2_temp]
        g1_temp = G_info_updated[g1_temp]
        g2_temp = G_info_updated[g2_temp]
        # add the edge 
        f1_fanout = len(list(kgss_graph.successors(f1_temp)))
        f2_fanout = len(list(kgss_graph.successors(f2_temp)))
        if f1_fanout > 1 and f2_fanout == 1:
            kgss_graph.add_edge(f2_temp, g1_temp)
        elif f1_fanout == 1 and f2_fanout > 1:
            kgss_graph.add_edge(f1_temp, g2_temp)
        elif f1_fanout > 1 and f2_fanout > 1:
            # kgss_graph.add_edge(f2_temp, g1_temp)
            kgss_graph.add_edge(f1_temp, g2_temp)
        else:
            print("error")
    # attack_f1f2= []
    # attack_f1f2name = []
    key_string = ''
    for item in kgss_data:
        [f1, f2] = [int(i) for i in item[0:2]]
        key_temp = int(item[4])
        # based on the count number, find the node name
        f1 = G_info_updated[f1]
        f2 = G_info_updated[f2]
        # g1 = G_info_updated[g1]
        # g2 = G_info_updated[g2]
        # find the fanout size of f1 and f2
        f1_fanout = len(list(kgss_graph.successors(f1)))
        f2_fanout = len(list(kgss_graph.successors(f2)))
        if f1_fanout >1 and f2_fanout > 1:
                key_string += 'X'
        if key_temp == 0:
            if f1_fanout == 1:
                key_string += '0'
            elif f2_fanout == 1:
                key_string += '1'
        elif key_temp == 1:
            if f1_fanout == 1:
                key_string += '1'
            elif f2_fanout == 1:
                key_string += '0'
        # else:
        #     key_string += 'X'
        #     attack_f1f2name.append([f1, f2])
        #     attack_f1f2.append([f1_fanout, f2_fanout])
    # print("attack_f1f2", attack_f1f2)
    # print("attack_f1f2name", attack_f1f2name)
    # print(len(kgss_data))
    # print("original_key", original_key)
    print("key_string", len(key_string))
    key_X_count = key_string.count('X')
    print("key_X_count", key_X_count)
    # key_acc = (len(original_key)-key_X_count)/len(original_key)
    key_acc = get_key_result(original_key, key_string)    
    return key_acc

# this function is used to attack the circuit using SAAM algorithm
def saam_attack_s4(netlist_str, circuit_name, kgss):
    # encode the netlist and get the
    kgss_ori = netlist_encode(netlist_str, circuit_name)
    # get the solution data
    kgss_data = kgss.data
    # print("kgss_data", kgss_data)
    kgss_graph = kgss_ori.graph
    original_key = kgss.get_key_value()
    G_info = dict(list(kgss_graph.nodes(data="count")))
    G_info_updated = {y: x for x, y in G_info.items()}
    for item in kgss_data:
        [f1_temp, f2_temp, g1_temp, g2_temp] = [int(i) for i in item[0:4]]
        f1_temp = G_info_updated[f1_temp]
        f2_temp = G_info_updated[f2_temp]
        g1_temp = G_info_updated[g1_temp]
        g2_temp = G_info_updated[g2_temp]
        # add the edge 
        kgss_graph.add_edge(f2_temp, g1_temp)
        kgss_graph.add_edge(f1_temp, g2_temp)
    # attack_f1f2= []
    # attack_f1f2name = []
    key_string = ''
    for item in kgss_data:
        [f1, f2] = [int(i) for i in item[0:2]]
        key_temp = int(item[4])
        # based on the count number, find the node name
        f1 = G_info_updated[f1]
        f2 = G_info_updated[f2]
        # g1 = G_info_updated[g1]
        # g2 = G_info_updated[g2]
        # find the fanout size of f1 and f2
        f1_fanout = len(list(kgss_graph.successors(f1)))
        f2_fanout = len(list(kgss_graph.successors(f2)))
        if f1_fanout >1 and f2_fanout > 1:
                key_string += 'X'
        if key_temp == 0:
            if f1_fanout == 1:
                key_string += '0'
            elif f2_fanout == 1:
                key_string += '1'
        elif key_temp == 1:
            if f1_fanout == 1:
                key_string += '1'
            elif f2_fanout == 1:
                key_string += '0'
        # else:
        #     key_string += 'X'
        #     attack_f1f2name.append([f1, f2])
        #     attack_f1f2.append([f1_fanout, f2_fanout])
    # print("attack_f1f2", attack_f1f2)
    # print("attack_f1f2name", attack_f1f2name)
    # print(len(kgss_data))
    # print("original_key", original_key)
    print("key_string", len(key_string))
    key_X_count = key_string.count('X')
    print("key_X_count", key_X_count)
    # key_acc = (len(original_key)-key_X_count)/len(original_key)
    key_acc = get_key_result(original_key, key_string)    
    return key_acc

def saam_attack_loc(netlist_str, circuit_name, kgss):
    # encode the netlist and get the
    kgss_ori = netlist_encode(netlist_str, circuit_name)
    # get the solution data
    kgss_data = kgss.data
    # print("kgss_data", kgss_data)
    kgss_graph = kgss_ori.graph
    original_key = kgss.get_key_value()
    G_info = dict(list(kgss_graph.nodes(data="count")))
    G_info_updated = {y: x for x, y in G_info.items()}
    for item in kgss_data:
        [_, f2_temp, g1_temp] = [int(i) for i in item[0:3]]
        # f1_temp = G_info_updated[f1_temp]
        f2_temp = G_info_updated[f2_temp]
        g1_temp = G_info_updated[g1_temp]
        # add the edge 
        kgss_graph.add_edge(f2_temp, g1_temp)
    # attack_f1f2= []
    # attack_f1f2name = []
    key_string = ''
    loc_index = []
    for item in kgss_data:
        index = kgss_data.index(item)
        [f1, f2] = [int(i) for i in item[0:2]]
        key_temp = int(item[4])
        # based on the count number, find the node name
        f1 = G_info_updated[f1]
        f2 = G_info_updated[f2]
        # g1 = G_info_updated[g1]
        # g2 = G_info_updated[g2]
        # find the fanout size of f1 and f2
        f1_fanout = len(list(kgss_graph.successors(f1)))
        f2_fanout = len(list(kgss_graph.successors(f2)))
        if f1_fanout >1 and f2_fanout > 1:
                key_string += 'X'
                loc_index.append(index)
        if key_temp == 0:
            # if f1_fanout >1 and f2_fanout > 1:
            #     key_string += 'X'
            #     loc_index.append(index)
            if f1_fanout == 1:
                key_string += '0'
            elif f2_fanout == 1:
                key_string += '1'
        elif key_temp == 1:
            if f1_fanout == 1:
                key_string += '1'
            elif f2_fanout == 1:
                key_string += '0'

        # else:
        #     key_string += 'X'
        #     attack_f1f2name.append([f1, f2])
        #     attack_f1f2.append([f1_fanout, f2_fanout])
    # print("attack_f1f2", attack_f1f2)
    # print("attack_f1f2name", attack_f1f2name)
    # print(len(kgss_data))
    # print("original_key", original_key)
    # print("key_string", len(key_string))
    # key_acc = get_key_result(original_key, key_string)    
    # return key_acc

    # # encode the netlist and get the
    # kgss = netlist_encode(netlist_str, circuit_name)
    # # get the solution data
    # kgss_data = kgss.data
    # # print("kgss_data", kgss_data)
    # kgss_graph = kgss.graph
    # original_key = kgss.get_key_value()
    # G_info = dict(list(kgss_graph.nodes(data="count")))
    # G_info_updated = {y: x for x, y in G_info.items()}
    # # attack_f1f2= []
    # key_string = ''
    # loc_index = []
    # for item in kgss_data:
    #     index = kgss_data.index(item)
    #     [f1, f2] = [int(i) for i in item[0:2]]
    #     # based on the count number, find the node name
    #     f1 = G_info_updated[f1]
    #     f2 = G_info_updated[f2]
    #     # g1 = G_info_updated[g1]
    #     # g2 = G_info_updated[g2]
    #     # find the fanout size of f1 and f2
    #     f1_fanout = len(list(kgss_graph.successors(f1)))
    #     f2_fanout = len(list(kgss_graph.successors(f2)))
    #     if f1_fanout >1 and f2_fanout > 1:
    #         key_string += 'X'
    #         loc_index.append(index)
    #     elif f1_fanout == 1:
    #         key_string += '0'
    #         # loc_index.append(index)
    #     elif f2_fanout == 1:
    #         key_string += '1'
    #         # loc_index.append(index)
    #     else:
    #         key_string += 'X'
    #         loc_index.append(index)
    # # print(len(kgss_data))
    # # print("original_key", original_key)
    # # print("key_string", key_string)
    # key_acc = get_key_result(original_key, key_string)    
    return loc_index

def dmux_type_check(netlist_str, circuit_name, kgss):
    # encode the netlist and get the
    kgss_ori = netlist_encode(netlist_str, circuit_name)
    # get the solution data
    kgss_data = kgss.data
    # print("kgss_data", kgss_data)
    kgss_graph = kgss_ori.graph
    original_key = kgss.get_key_value()
    G_info = dict(list(kgss_graph.nodes(data="count")))
    # print(G_info)
    # G_info1 = dict(list(kgss_graph.nodes(data="count")))
    # print(G_info1)

    G_info_updated = {y: x for x, y in G_info.items()}
    for item in kgss_data:
        [_, f2_temp, g1_temp] = [int(i) for i in item[0:3]]
        # f1_temp = G_info_updated[f1_temp]
        f2_temp = G_info_updated[f2_temp]
        g1_temp = G_info_updated[g1_temp]
        # add the edge 
        kgss_graph.add_edge(f2_temp, g1_temp)
    # attack_f1f2= []
    # attack_f1f2name = []
    key_string = ''
    S_type = []
    
    for item in kgss_data:
        [f1, f2] = [int(i) for i in item[0:2]]
        # based on the count number, find the node name
        f1 = G_info_updated[f1]
        f2 = G_info_updated[f2]
        # g1 = G_info_updated[g1]
        # g2 = G_info_updated[g2]
        # find the fanout size of f1 and f2
        f1_fanout = len(list(kgss_graph.successors(f1)))
        f2_fanout = len(list(kgss_graph.successors(f2)))
        if f2_fanout == 2 and f1_fanout > 1:
            S_type.append("S3")
        # elif f1_fanout ==  2 and f2_fanout > 1:
        #     S_type.append("S3")
        elif f1_fanout > 1  and f2_fanout > 1 :
            S_type.append("S2")
        else:
            S_type.append("S_new")
            print(f1_fanout, f2_fanout)
            print(f1, f2)
    
    # count the number of S2 and S3
    S2_count = S_type.count("S2")
    S3_count = S_type.count("S3")


        #     key_string += 'X'
        #     # attack_f1f2name.append([f1, f2])
        #     # attack_f1f2.append([f1_fanout, f2_fanout])
        # elif f1_fanout == 1:
        #     key_string += '1'
        # elif f2_fanout == 1:
        #     key_string += '0'
        # else:
        #     key_string += 'X'
        #     attack_f1f2name.append([f1, f2])
        #     attack_f1f2.append([f1_fanout, f2_fanout])
    # print("attack_f1f2", attack_f1f2)
    # print("attack_f1f2name", attack_f1f2name)
    # print(len(kgss_data))
    # print("original_key", original_key)
    # print("key_string", len(key_string))
    # key_acc = get_key_result(original_key, key_string)    
    return S_type, S2_count, S3_count
# saam_attack

