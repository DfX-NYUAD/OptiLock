import os
import shutil
import subprocess

# this function is used to get the key acc/precision/kpa from the key string
def get_key_result(key_string_ori, key_string_extracted):
    key_ori_list = list(key_string_ori)
    key_extracted_list = list(key_string_extracted)
    # print(key_ori_list)
    # print(key_extracted_list)
    key_acc = 0
    key_pre = 0
    key_kpa = 0
    for i in range(len(key_ori_list)):
        if key_ori_list[i] == key_extracted_list[i]:
            key_acc += 1
        elif key_extracted_list[i] == 'X':
            key_pre += 1
    # print(key_pre)
    key_acc_prec = key_acc / len(key_ori_list)
    key_pre_prec = (key_pre + key_acc) / len(key_ori_list)
    if len(key_ori_list)-key_pre == 0:
        key_kpa_prec = 0
    else:
        key_kpa_prec = key_acc / (len(key_ori_list) - key_pre)
    key_X_prec = key_pre/ len(key_ori_list) #(key_kpa_prec-key_acc_prec)/key_kpa_prec
    print(key_acc_prec, key_pre_prec, key_kpa_prec, key_X_prec)
    return [key_acc_prec, key_pre_prec, key_kpa_prec, key_X_prec]

# this function is used to extracted the key result for the optilock
def extract_key_acc(base_path):
    # file base path
    # base_path = "/scratch/zw3464/ec-ll-SA-master/src/SCOPE/"
    # check if there are files in the attacked_files folder
    attack_file_list = os.listdir(base_path + "attacked_files")
    # if there is any files in the folder, remove all of them
    # if len(attack_file_list) > 0:
    #     for file in file_list:
    #         os.remove(base_path + "attacked_files/" + file)
    # copy the attacked files to the folder
    
    # get the two key variant from the result
    key_file_list = os.listdir(base_path + "extracted_keys")
    if len(key_file_list) > 0:
        for file in key_file_list:
            # remove the folder
            shutil.rmtree(base_path + "extracted_keys/" + file)
            # print(file)
    # run the scope 
    # enter the specific folder
    os.chdir(base_path)
    subprocess.run( "./src/scope", stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, shell=True)
    # return back
    os.chdir("../src/")
    # os.system("./src/scope")
    # get the key files
    key_file_list = os.listdir(base_path + "extracted_keys")
    for attack_file in attack_file_list:
        with open(base_path + "attacked_files/" + attack_file, 'r') as file:
            first_line = file.readline().strip()
        # print(first_line)
        key_string = first_line.split("=")[-1]
        # print(key_string)
        # find the extracted key file
        extracted_key_result = []
        for key_file in key_file_list:
            if  attack_file.split(".")[0] in key_file:
                
                # read the key file
                with open(base_path + "extracted_keys/" + key_file + "/key_variant_1.txt", 'r') as file:
                    key_file_content = file.read().strip()
                extracted_key_result.append(key_file_content)
                with open(base_path + "extracted_keys/" + key_file + "/key_variant_2.txt", 'r') as file:
                    key_file_content = file.read().strip()
                extracted_key_result.append(key_file_content)
        key_acc_list = []
        for key in extracted_key_result:
            key_temp = key[:len(key_string)]
            key_acc = get_key_result(key_string, key_temp)[0]
            key_acc_list.append(key_acc)
        key_acc_max = max(key_acc_list)
        # print(key_acc_list)
        return float(key_acc_max)

# this function is used to extracted the key result for the optilock
def extract_key_all(base_path):
    # file base path
    # base_path = "/scratch/zw3464/ec-ll-SA-master/src/SCOPE/"
    # check if there are files in the attacked_files folder
    attack_file_list = os.listdir(base_path + "attacked_files")
    # if there is any files in the folder, remove all of them
    # if len(attack_file_list) > 0:
    #     for file in file_list:
    #         os.remove(base_path + "attacked_files/" + file)
    # copy the attacked files to the folder
    
    # get the two key variant from the result
    key_file_list = os.listdir(base_path + "extracted_keys")
    if len(key_file_list) > 0:
        for file in key_file_list:
            # remove the folder
            shutil.rmtree(base_path + "extracted_keys/" + file)
            # print(file)
    # run the scope 
    # enter the specific folder
    os.chdir(base_path)
    subprocess.run( "./src/scope", stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, shell=True)
    # return back
    os.chdir("../src/")
    # os.system("./src/scope")
    # get the key files
    key_file_list = os.listdir(base_path + "extracted_keys")
    for attack_file in attack_file_list:
        with open(base_path + "attacked_files/" + attack_file, 'r') as file:
            first_line = file.readline().strip()
        # print(first_line)
        key_string = first_line.split("=")[-1]
        # print(key_string)
        # find the extracted key file
        extracted_key_result = []
        for key_file in key_file_list:
            if  attack_file.split(".")[0] in key_file:
                
                # read the key file
                with open(base_path + "extracted_keys/" + key_file + "/key_variant_1.txt", 'r') as file:
                    key_file_content = file.read().strip()
                extracted_key_result.append(key_file_content)
                with open(base_path + "extracted_keys/" + key_file + "/key_variant_2.txt", 'r') as file:
                    key_file_content = file.read().strip()
                extracted_key_result.append(key_file_content)
        key_acc_list = []
        key_all_list = []
        for key in extracted_key_result:
            key_temp = key[:len(key_string)]
            key_acc = get_key_result(key_string, key_temp)[0]
            key_all_list.append(get_key_result(key_string, key_temp))
            key_acc_list.append(key_acc)
        key_acc_max = max(key_acc_list)
        # print the index of max
        max_index = key_acc_list.index(key_acc_max)
        key_best_all = key_all_list[max_index]

        # print(key_acc_list)
        return key_best_all

# this function is used to extracted the key result for the optilock
def extract_key_loc(base_path):
    # file base path
    # base_path = "/scratch/zw3464/ec-ll-SA-master/src/SCOPE/"
    # check if there are files in the attacked_files folder
    attack_file_list = os.listdir(base_path + "attacked_files")
    # if there is any files in the folder, remove all of them
    # if len(attack_file_list) > 0:
    #     for file in file_list:
    #         os.remove(base_path + "attacked_files/" + file)
    # copy the attacked files to the folder
    
    # get the two key variant from the result
    key_file_list = os.listdir(base_path + "extracted_keys")
    if len(key_file_list) > 0:
        for file in key_file_list:
            # remove the folder
            shutil.rmtree(base_path + "extracted_keys/" + file)
            # print(file)
    # run the scope 
    # enter the specific folder
    os.chdir(base_path)
    subprocess.run( "./src/scope", stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, shell=True)
    # return back
    os.chdir("../src/")
    # os.system("./src/scope")
    # get the key files
    key_file_list = os.listdir(base_path + "extracted_keys")
    for attack_file in attack_file_list:
        with open(base_path + "attacked_files/" + attack_file, 'r') as file:
            first_line = file.readline().strip()
        # print(first_line)
        key_string = first_line.split("=")[-1]
        # print(key_string)
        # find the extracted key file
        extracted_key_result = []
        for key_file in key_file_list:
            if  attack_file.split(".")[0] in key_file:
                
                # read the key file
                with open(base_path + "extracted_keys/" + key_file + "/key_variant_1.txt", 'r') as file:
                    key_file_content = file.read().strip()
                extracted_key_result.append(key_file_content)
                with open(base_path + "extracted_keys/" + key_file + "/key_variant_2.txt", 'r') as file:
                    key_file_content = file.read().strip()
                extracted_key_result.append(key_file_content)
        key_acc_list = []
        key_all_list = []
        for key in extracted_key_result:
            key_temp = key[:len(key_string)]
            key_acc = get_key_result(key_string, key_temp)[0]
            key_all_list.append(get_key_result(key_string, key_temp))
            key_acc_list.append(key_acc)
        key_acc_max = max(key_acc_list)
        # print the index of max
        max_index = key_acc_list.index(key_acc_max)
        # key_best_all = key_all_list[max_index]
        extracted_key = extracted_key_result[max_index]
        key_loc = []
        for i in range(len(extracted_key)):
            # if extracted_key[i] == 'X':
            #     key_loc.append(i)
            if extracted_key[i] != key_string[i]:
                key_loc.append(i)
        

        # print(key_acc_list)
        return key_loc



    # print(file_list)

# extract_key_result()

# this function is used to extract the average key accuracy
def get_key_results(circuit_name):
    # base path
    base_path = "/scratch/zw3464/ec-ll-SA-master/SCOPE_" + circuit_name + "/"
    # get the key acc for the optilock
    extracted_folder1 = base_path + "extracted_keys"
    key_result_list = []
    for index in range(1, 11):
        # get the key acc for the optilock
        with open(base_path + "attacked_files/" + circuit_name + "_locked" + str(index) +".bench", 'r') as file:
            first_line = file.readline().strip()
        key_string = first_line.split("=")[-1]
        extracted_folder = extracted_folder1 + "/" + circuit_name + "_locked" + str(index)
        # read the key file
        extracted_key_result = []
        with open(extracted_folder + "/key_variant_1.txt", 'r') as file:
            key_file_content = file.read().strip()
            extracted_key_result.append(key_file_content)
        with open(extracted_folder  + "/key_variant_2.txt", 'r') as file:
            key_file_content = file.read().strip()
            extracted_key_result.append(key_file_content)
        
        key_acc_list = []
        key_all_list = []
        for key in extracted_key_result:
            key_temp = key[:len(key_string)]
            key_acc = get_key_result(key_string, key_temp)[0]
            key_all_list.append(get_key_result(key_string, key_temp))
            key_acc_list.append(key_acc)
        key_acc_max = max(key_acc_list)
        # print the index of max
        max_index = key_acc_list.index(key_acc_max)
        key_best_all = key_all_list[max_index]
        # print(key_best_all)
        key_result_list.append(key_best_all)
    
    # for first 5 list, get the key accuracy average
    key_result_list1 = key_result_list[:5]
    key_acc_sum = 0
    key_pre_sum = 0
    key_kpa_sum = 0
    key_X_sum = 0
    for key in key_result_list1:
        key_acc_sum += key[0]
        key_pre_sum += key[1]
        key_kpa_sum += key[2]
        key_X_sum += key[3]
    key_acc_avg = key_acc_sum / 5
    key_pre_avg = key_pre_sum / 5
    key_kpa_avg = key_kpa_sum / 5
    key_X_avg = key_X_sum / 5
    print("final 1")
    print(key_acc_avg, key_pre_avg, key_kpa_avg, key_X_avg)
    # get the last 5 key accuracy
    key_result_list2 = key_result_list[5:]
    key_acc_sum = 0
    key_pre_sum = 0
    key_kpa_sum = 0
    key_X_sum = 0
    for key in key_result_list2:
        key_acc_sum += key[0]
        key_pre_sum += key[1]
        key_kpa_sum += key[2]
        key_X_sum += key[3]
    key_acc_avg = key_acc_sum / 5
    key_pre_avg = key_pre_sum / 5
    key_kpa_avg = key_kpa_sum / 5
    key_X_avg = key_X_sum / 5
    print("final 2")
    print(key_acc_avg, key_pre_avg, key_kpa_avg, key_X_avg)


# get_key_results("b22")
        