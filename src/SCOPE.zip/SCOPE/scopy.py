#!/usr/bin/python
import torch
import numpy as np
import sys, copy
import os.path
import random

from ec.impl.kgs_solution import KGSSolution

sys.path.append('%s/../pytorch_DGCNN' % os.path.dirname(os.path.realpath(__file__)))
import os
import re
import shutil
import networkx as nx
from muxlink.original import *
# import threading
# import time
from multiprocessing import Process
# from src.muxlink.original import *


def GenerateKey(K):
    nums = np.ones(K)
    nums[0:(K // 2)] = 0
    np.random.shuffle(nums)
    return nums


def ExtractSingleMultiOutputNodes(G):
    F_multi = []
    F_single = []
    for n in G.nodes():
        out_degree = G.out_degree(n)
        check = G.nodes[n]['output']
        if out_degree == 1:
            if G.nodes[n]['gate'] != "input" and not check:
                F_single.append(n)
        elif out_degree > 1:
            if G.nodes[n]['gate'] != "input" and not check:
                F_multi.append(n)
    return F_multi, F_single


def verilog2gates(verilog):
    Dict_gates = {'xor': [0, 1, 0, 0, 0, 0, 0, 0],
                  'XOR': [0, 1, 0, 0, 0, 0, 0, 0],
                  'OR': [0, 0, 1, 0, 0, 0, 0, 0],
                  'or': [0, 0, 1, 0, 0, 0, 0, 0],
                  'XNOR': [0, 0, 0, 1, 0, 0, 0, 0],
                  'xnor': [0, 0, 0, 1, 0, 0, 0, 0],
                  'and': [0, 0, 0, 0, 1, 0, 0, 0],
                  'AND': [0, 0, 0, 0, 1, 0, 0, 0],
                  'nand': [0, 0, 0, 0, 0, 1, 0, 0],
                  'buf': [0, 0, 0, 0, 0, 0, 0, 1],
                  'BUF': [0, 0, 0, 0, 0, 0, 0, 1],
                  'NAND': [0, 0, 0, 0, 0, 1, 0, 0],
                  'not': [0, 0, 0, 0, 0, 0, 1, 0],
                  'NOT': [0, 0, 0, 0, 0, 0, 1, 0],
                  'nor': [1, 0, 0, 0, 0, 0, 0, 0],
                  'NOR': [1, 0, 0, 0, 0, 0, 0, 0],
                  }
    G = nx.DiGraph()
    ML_count = 0
    regex = "\s*(\S+)\s*=\s*(BUF|NOT)\((\S+)\)\s*"
    for output, function, net_str in re.findall(regex, verilog, flags=re.I | re.DOTALL):
        input = net_str.replace(" ", "")
        G.add_edge(input, output)
        G.nodes[output]['gate'] = function
        G.nodes[output]['count'] = ML_count
        ML_count += 1
    regex = "(\S+)\s*=\s*(OR|XOR|AND|NAND|XNOR|NOR)\((.+?)\)\s*"
    for output, function, net_str in re.findall(regex, verilog, flags=re.I | re.DOTALL):
        nets = net_str.replace(" ", "").replace("\n", "").replace("\t", "").split(",")
        inputs = nets
        G.add_edges_from((net, output) for net in inputs)
        G.nodes[output]['gate'] = function
        G.nodes[output]['count'] = ML_count
        ML_count += 1
    for n in G.nodes():
        if 'gate' not in G.nodes[n]:
            G.nodes[n]['gate'] = 'input'
    for n in G.nodes:
        G.nodes[n]['output'] = False
    out_regex = "OUTPUT\((.+?)\)\n"
    for net_str in re.findall(out_regex, verilog, flags=re.I | re.DOTALL):
        nets = net_str.replace(" ", "").replace("\n", "").replace("\t", "").split(",")
        for net in nets:
            if net in G:
                G.nodes[net]['output'] = True
    # print("G nodes numer", G.nodes())
    return G


def read_string(path):
    with open(path, 'r') as f:
        data = f.read()
    return data


def verilog2gates_train(f_link_train, f_link_train_f, verilog, f_feat, f_cell, f_count, dump):
    Dict_gates = {'xor': [0, 1, 0, 0, 0, 0, 0, 0],
                  'XOR': [0, 1, 0, 0, 0, 0, 0, 0],
                  'OR': [0, 0, 1, 0, 0, 0, 0, 0],
                  'or': [0, 0, 1, 0, 0, 0, 0, 0],
                  'XNOR': [0, 0, 0, 1, 0, 0, 0, 0],
                  'xnor': [0, 0, 0, 1, 0, 0, 0, 0],
                  'and': [0, 0, 0, 0, 1, 0, 0, 0],
                  'AND': [0, 0, 0, 0, 1, 0, 0, 0],
                  'nand': [0, 0, 0, 0, 0, 1, 0, 0],
                  'buf': [0, 0, 0, 0, 0, 0, 0, 1],
                  'BUF': [0, 0, 0, 0, 0, 0, 0, 1],
                  'NAND': [0, 0, 0, 0, 0, 1, 0, 0],
                  'not': [0, 0, 0, 0, 0, 0, 1, 0],
                  'NOT': [0, 0, 0, 0, 0, 0, 1, 0],
                  'nor': [1, 0, 0, 0, 0, 0, 0, 0],
                  'NOR': [1, 0, 0, 0, 0, 0, 0, 0],
                  }
    G = nx.DiGraph()
    ML_count = 0
    regex = "\s*(\S+)\s*=\s*(BUF|NOT)\((\S+)\)\s*"
    for output, function, net_str in re.findall(regex, verilog, flags=re.I | re.DOTALL):
        input = net_str.replace(" ", "")

        G.add_edge(input, output)
        G.nodes[output]['gate'] = function
        G.nodes[output]['count'] = ML_count
        if dump:

            feat = Dict_gates[function]
            for item in feat:
                f_feat.write(str(item) + " ")
            f_feat.write("\n")
            f_cell.write(str(ML_count) + " assign for output " + output + "\n")
            f_count.write(str(ML_count) + "\n")
        ML_count += 1
    regex = "(\S+)\s*=\s*(OR|XOR|AND|NAND|XNOR|NOR)\((.+?)\)\s*"
    for output, function, net_str in re.findall(regex, verilog, flags=re.I | re.DOTALL):
        nets = net_str.replace(" ", "").replace("\n", "").replace("\t", "").split(",")
        inputs = nets
        G.add_edges_from((net, output) for net in inputs)
        G.nodes[output]['gate'] = function
        G.nodes[output]['count'] = ML_count
        if dump:
            feat = Dict_gates[function]
            for item in feat:
                f_feat.write(str(item) + " ")
            f_feat.write("\n")
            f_cell.write(str(ML_count) + " assign for output " + output + "\n")
            f_count.write(str(ML_count) + "\n")
        ML_count += 1
    for n in G.nodes():
        if 'gate' not in G.nodes[n]:
            G.nodes[n]['gate'] = 'input'
    for n in G.nodes:
        G.nodes[n]['output'] = False
    out_regex = "OUTPUT\((.+?)\)\n"
    for net_str in re.findall(out_regex, verilog, flags=re.I | re.DOTALL):
        nets = net_str.replace(" ", "").replace("\n", "").replace("\t", "").split(",")
        for net in nets:
            if net not in G:
                print("Output " + net + " is Float")
            else:
                G.nodes[net]['output'] = True
    if dump:
        for u, v in G.edges:
            if 'count' in G.nodes[u].keys() and 'count' in G.nodes[v].keys():
                f_link_train.write(str(G.nodes[u]['count']) + " " + str(G.nodes[v]['count']) + "\n")
    return G


def verilog2gates_locked(f_link_train, f_link_train_f, f_link_test, f_link_test_neg, verilog, f_feat, f_cell, f_count,
                         dump):
    key_size = 0
    Dict_gates = {'xor': [0, 1, 0, 0, 0, 0, 0, 0],
                  'XOR': [0, 1, 0, 0, 0, 0, 0, 0],
                  'OR': [0, 0, 1, 0, 0, 0, 0, 0],
                  'or': [0, 0, 1, 0, 0, 0, 0, 0],
                  'XNOR': [0, 0, 0, 1, 0, 0, 0, 0],
                  'xnor': [0, 0, 0, 1, 0, 0, 0, 0],
                  'and': [0, 0, 0, 0, 1, 0, 0, 0],
                  'AND': [0, 0, 0, 0, 1, 0, 0, 0],
                  'nand': [0, 0, 0, 0, 0, 1, 0, 0],
                  'buf': [0, 0, 0, 0, 0, 0, 0, 1],
                  'BUF': [0, 0, 0, 0, 0, 0, 0, 1],
                  'BUFF': [0, 0, 0, 0, 0, 0, 0, 1],
                  'NAND': [0, 0, 0, 0, 0, 1, 0, 0],
                  'not': [0, 0, 0, 0, 0, 0, 1, 0],
                  'NOT': [0, 0, 0, 0, 0, 0, 1, 0],
                  'nor': [1, 0, 0, 0, 0, 0, 0, 0],
                  'NOR': [1, 0, 0, 0, 0, 0, 0, 0],
                  }
    G = nx.DiGraph()
    ML_count = 0
    regex = "\s*(\S+)\s*=\s*(BUF|BUFF|NOT)\((\S+)\)\s*"
    for output, function, net_str in re.findall(regex, verilog, flags=re.I | re.DOTALL):
        input = net_str.replace(" ", "")

        G.add_edge(input, output)
        G.nodes[output]['gate'] = function
        G.nodes[output]['count'] = ML_count
        if dump:

            feat = Dict_gates[function]
            for item in feat:
                f_feat.write(str(item) + " ")
            f_feat.write("\n")
            f_cell.write(str(ML_count) + " assign for output " + output + "\n")
            f_count.write(str(ML_count) + "\n")
        ML_count += 1
    regex = "(\S+)\s*=\s*(OR|XOR|AND|NAND|XNOR|NOR)\((.+?)\)\s*"
    for output, function, net_str in re.findall(regex, verilog, flags=re.I | re.DOTALL):
        nets = net_str.replace(" ", "").replace("\n", "").replace("\t", "").split(",")
        inputs = nets
        G.add_edges_from((net, output) for net in inputs)
        G.nodes[output]['gate'] = function
        G.nodes[output]['count'] = ML_count
        if dump:
            feat = Dict_gates[function]
            for item in feat:
                f_feat.write(str(item) + " ")
            f_feat.write("\n")
            f_cell.write(str(ML_count) + " assign for output " + output + "\n")
            f_count.write(str(ML_count) + "\n")
        ML_count += 1
    for n in G.nodes():
        if 'gate' not in G.nodes[n]:
            G.nodes[n]['gate'] = 'input'
    for n in G.nodes:
        G.nodes[n]['output'] = False
    out_regex = "OUTPUT\((.+?)\)\n"
    for net_str in re.findall(out_regex, verilog, flags=re.I | re.DOTALL):
        nets = net_str.replace(" ", "").replace("\n", "").replace("\t", "").split(",")
        for net in nets:
            if net not in G:
                print("Output " + net + " is Float")
            else:
                G.nodes[net]['output'] = True
    regex = "#key=(\d+)\s*"
    for key_bits in re.findall(regex, verilog, flags=re.I | re.DOTALL):
        key_size = len(key_bits)
        # print(key_bits)
        # print("Key size is "+str(key_size))
        i = 0
        K_list = np.ones(key_size)
        for bit in key_bits:
            K_list[i] = int(bit)
            i = i + 1
        # print(K_list)
    # debug - Zeng
    # print("G nodes list: ", G.nodes())
    # print("G nodes list has count: ", dict(G.nodes(data='count')))
    regex = "(\S+)\s*=\s*(MUX)\((.+?)\)\s*"
    for output, function, net_str in re.findall(regex, verilog, flags=re.I | re.DOTALL):
        nets = net_str.replace(" ", "").replace("\n", "").replace("\t", "").split(",")
        inputs = nets
        output_x = output.replace('_from_mux', '')
        regex_key = "keyinput(\d+)"
        for key_bit in re.findall(regex_key, inputs[0], flags=re.I | re.DOTALL):
            key_bit_value = K_list[int(key_bit)]
            correct = ""
            false = ""
            # debug - Zeng
            # print("inputs: ", inputs)
            if key_bit_value == 0:
                correct = inputs[1]
                false = inputs[2]
                f_link_test.write(str(G.nodes[correct]['count']) + " " + str(G.nodes[output_x]['count']) + "\n")

                f_link_test_neg.write(str(G.nodes[false]['count']) + " " + str(G.nodes[output_x]['count']) + "\n")
            else:

                correct = inputs[2]
                false = inputs[1]

                f_link_test.write(str(G.nodes[correct]['count']) + " " + str(G.nodes[output_x]['count']) + "\n")

                f_link_test_neg.write(str(G.nodes[false]['count']) + " " + str(G.nodes[output_x]['count']) + "\n")
    i = 0

    if dump:
        for u, v in G.edges:
            if 'count' in G.nodes[u].keys() and 'count' in G.nodes[v].keys():
                f_link_train.write(str(G.nodes[u]['count']) + " " + str(G.nodes[v]['count']) + "\n")
    return G, key_size


class SCOPE:
    def __init__(self):
        pass

    def FindPairs(self, S_sel, F_single, F_multi, I_max, O_max, G, selected_g):
        F1 = []
        F2 = []
        F1 = F_multi + F_single
        F2 = F_multi + F_single
        done = False
        i = 0
        f1 = ""
        f2 = ""
        g1 = ""
        while i < I_max:
            f1 = random.choice(F1)
            f2 = f1
            while f2 == f1:
                f2 = random.choice(F2)
            ## here is to make sure f1 != f2

            j = 0
            while j < O_max:
                g1 = random.choice(list(G.successors(f1)))
                R1 = nx.has_path(G, g1, f2)
                if not R1:
                    if g1 not in selected_g:
                        done = True
                        break
                j = j + 1
            if done:
                break
            i = i + 1
        if done:
            G.add_edge(f2, g1)

        return f1, f2, g1, done, G
    
    def lock(self, bench_as_a_string, key_len, d_mux_type):
        c = verilog2gates(bench_as_a_string)
        new_c = verilog2gates(bench_as_a_string)
        self.F_multi, self.F_single = ExtractSingleMultiOutputNodes(c)  # TODO: this could be done once
        # Generate the key
        K_list = GenerateKey(key_len)
        counter = key_len - 1
        myDict = {}
        # if d_mux_type == "eD-MUX":
        #     L_s = np.array(["s1", "s2", "s3"])
        # else:
        #     L_s = np.array([])

        selected_f1_gates = []
        selected_f2_gates = []
        # selected_g2_gates = []
        selected_g1_gates = []
        selected_g = []
        break_out = 0
        while counter >= 0:
            # np.random.shuffle(L_s)
            fallback = True
            S_sel = ""
            # for s in L_s:
            #     if s == "s1" and counter < 2:
            #         continue  ## no operation???
            #     elif s == "s3" and len(self.F_multi) > 1 and len(self.F_single) > 1:
            #         S_sel = s
            #         fallback = False
            #         break  ## no operation??
            #     elif len(self.F_multi) < 2:

            #         continue  ## no operations??
            #     S_sel = s
            #     fallback = False
            #     break
            # if fallback:
            #     S_sel = "s4"
            S_sel = "None"
            to_be_new_c = nx.DiGraph()
            done = False
            f1, f2, g1, done, to_be_new_c = self.FindPairs(S_sel, self.F_single, self.F_multi, 10, 10, new_c,
                                                               selected_g)
            if not done:
                break_out += 1
                if (break_out >= 10):
                    break_out = 0
                    S_sel = "None"
                    while not done:
                        # each time find one pair(f1, f2, g1, g2)
                        f1, f2, g1, done, to_be_new_c = self.FindPairs("s4", self.F_single, self.F_multi, 10, 10,
                                                                           new_c,
                                                                           selected_g)
                else:
                    continue
            if len(list(nx.simple_cycles(to_be_new_c))) != 0:
                continue  # Zeng added : avoid generate the loop in the circuit
            new_c = copy.deepcopy(to_be_new_c)
            selected_f1_gates.append(f1)
            selected_f2_gates.append(f2)
            if f1 in self.F_multi:
                self.F_multi.remove(f1)
            elif f1 in self.F_single:
                self.F_single.remove(f1)
            if f2 in self.F_multi:
                self.F_multi.remove(f2)
            elif f2 in self.F_single:
                self.F_single.remove(f2)
            # if S_sel == "s1":
            #     myDict[g1] = [f1, f2, counter]
            #     # myDict[g2] = [f2, f1, counter - 1]
            #     counter = counter - 2
            #     selected_g1_gates.append(g1)
            #     selected_g2_gates.append(g2)
            #     selected_g.append(g1)
            #     selected_g.append(g2)
            # else:
            #     if S_sel == "s4":
            #         selected_g1_gates.append(g1)
            #         selected_g2_gates.append(g2)
            #         selected_g.append(g1)
            #         selected_g.append(g2)
            #         myDict[g1] = [f1, f2, counter]

            #         myDict[g2] = [f2, f1, counter]

            #     else:

            #         selected_g1_gates.append(g1)
            #         selected_g.append(g1)
            #         myDict[g1] = [f1, f2, counter]
            #     counter = counter - 1
            if S_sel == "None":
                selected_g1_gates.append(g1)
                selected_g.append(g1)
                myDict[g1] = [f1, f2, counter]
                counter = counter - 1
        if len(list(nx.simple_cycles(new_c))) != 0:
            sys.exit("There is a loop in the circuit!")
        locked_file = ""
        i = 0
        locked_file = locked_file + "#key="
        while i < key_len:
            locked_file = locked_file + str(int(K_list[i]))
            i = i + 1
        locked_file = locked_file + ("\n")
        i = 0
        while i < key_len+0:
            locked_file = locked_file + "INPUT(keyinput" + str(i) + ")\n"
            i = i + 1
        count = 0
        detected = 0

        for line in bench_as_a_string.split("\n"):
            count += 1
            line = line.strip()
            if any(ext + " =" in line for ext in selected_g):  # id -> gate_name -> search
                detected = detected + 1
                regex = "(\S+)\s*=\s*(NOT|BUF|OR|XOR|AND|NAND|XNOR|NOR)\((.+?)\)\s*"
                for output, function, net_str in re.findall(regex, line, flags=re.I | re.DOTALL):
                    if output in myDict.keys():
                        my_f1 = myDict[output][0]
                        my_f2 = myDict[output][1]
                        my_key = myDict[output][2]
                        line = line.replace(my_f1 + ",", output + "_from_mux,")
                        line = line.replace(my_f1 + ")", output + "_from_mux)")
                        locked_file = locked_file + (line + "\n")
                        if K_list[my_key] == 0:
                            locked_file = locked_file + output + "_from_mux = MUX(keyinput" + str(
                                my_key) + ", " + my_f1 + ", " + my_f2 + ")\n"
                        else:

                            locked_file = locked_file + output + "_from_mux = MUX(keyinput" + str(
                                my_key) + ", " + my_f2 + ", " + my_f1 + ")\n"
                    else:
                        locked_file = locked_file + line + "\n"
            else:
                locked_file = locked_file + line + "\n"

        # Done-lilas: this will be overwritten for each solution. Must be fixed (add solution id!)
        # Question: where do we read this check file again?
        # no need to keep solution id
        # text_file = open(self.model_path + "check_" + "original.txt", "w")
        # text_file.write(locked_file)
        # text_file.close()

        return locked_file